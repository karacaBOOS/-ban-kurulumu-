# IBAN.UNO — Premium landing page

Responsive, single-file HTML landing page with a premium black-and-gold visual style.

## Preview locally
Open `index.html` in a browser.

## Publish
Upload `index.html` to the root of a GitHub repository, then enable GitHub Pages or connect the repository to Vercel.

## Important
This is a front-end landing-page prototype only. Customer accounts, IBAN storage, NFC card provisioning, admin tools, and production security are not implemented yet. Do not collect real customer IBAN data through this static page.
